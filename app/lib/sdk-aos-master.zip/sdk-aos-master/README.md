sdk-aos
=======

LiqPay Android SDK

Documentation https://www.liqpay.ua/documentation/en